#include<stdio.h>
int main (){
    int a,b,sum,diffrence;
    float multiply, divide;
    printf("\t enter values for mathematical operations\n");
    printf("\t ----------------------------------------\n");
    printf("a:");
    scanf("%d",&a);
    printf("b:");
    scanf("%d",&b);
    sum=a+b;
    diffrence=a-b;
    multiply=a*b;
    divide=a/b;
    printf("sum=%d\n",sum);
    printf("diffrence=%d\n",diffrence);
    printf("multiply=%f\n",multiply);
    printf("divide=%f\n",divide);
    return 0;
}